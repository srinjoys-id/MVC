﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Web.Mvc;
using CMS;
using CMS.Controllers;
using CMS.Models;

namespace CMS_UnitTest
{
    [TestClass]
    public class ControllerTest
    {
        [TestMethod]
        public void TestIndexView()
        {
            //Arrange
            Customer_InfosController controller = new Customer_InfosController();

            //Act
            ViewResult result = controller.Index("Pincode", "777111") as ViewResult;

            //Assert
            Assert.IsNotNull(result.ViewName);

        }
    }
}
