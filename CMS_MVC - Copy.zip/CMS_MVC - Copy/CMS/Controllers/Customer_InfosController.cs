﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using CMS.Models;

namespace CMS.Controllers
{
    public class Customer_InfosController : Controller
    {
        private CustEntities db = new CustEntities();

        // GET: Customer_Infos
        public ActionResult Index(string option, string search)
        {
            if (option == "City")
            {
                //Index action method will return a view with a customer records based on what a user specify the value in textbox  
                return View(db.Customer_Infos.Where(x => x.city == search || search == null).ToList());
            }
            else if (option == "Pincode")
            {
                return View(db.Customer_Infos.Where(x => x.Pincode == search || search == null).ToList());
            }
            else
            {
                return View(db.Customer_Infos.Where(x => x.customer_name == search || search == null).ToList());
            }
        }

        // GET: Customer_Infos/Details/5
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer_Infos customer_Infos = db.Customer_Infos.Find(id);
            if (customer_Infos == null)
            {
                return HttpNotFound();
            }
            return View(customer_Infos);
        }

        // GET: Customer_Infos/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: Customer_Infos/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create([Bind(Include = "customerid,customer_name,city,age,phone,Pincode")] Customer_Infos customer_Infos)
        {
            //creating a  new customer record if details inserted are valid
            if (ModelState.IsValid)
            {
                db.Customer_Infos.Add(customer_Infos);
                db.SaveChanges();
                return RedirectToAction("Index");
            }

            return View(customer_Infos);
        }

        // GET: Customer_Infos/Edit/5
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer_Infos customer_Infos = db.Customer_Infos.Find(id);
            if (customer_Infos == null)
            {
                return HttpNotFound();
            }
            return View(customer_Infos);
        }

        // POST: Customer_Infos/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see https://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit([Bind(Include = "customerid,customer_name,city,age,phone,Pincode")] Customer_Infos customer_Infos)
        {
            //editing details of selected customer
            if (ModelState.IsValid)
            {
                db.Entry(customer_Infos).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(customer_Infos);
        }

        // GET: Customer_Infos/Delete/5
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Customer_Infos customer_Infos = db.Customer_Infos.Find(id);
            if (customer_Infos == null)
            {
                return HttpNotFound();
            }
            return View(customer_Infos);
        }

        // POST: Customer_Infos/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public ActionResult DeleteConfirmed(int id)
        {
            //Confirmation before deleting a customer's information
            Customer_Infos customer_Infos = db.Customer_Infos.Find(id);
            db.Customer_Infos.Remove(customer_Infos);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
